export const environment = {
  production: true,
  // AuthURL: 'http://localhost:29072/api',
  //  AuthURL: 'http://localhost:29072/api',
 //   CompURL: 'https://localhost:44342/api',
    AuthURL: 'http://authorization12.azurewebsites.net/api',
    CompURL: 'http://componentbackendservice.azurewebsites.net/api',

  //AuthURL: 'http://authorization12.azurewebsites.net/api',
};
