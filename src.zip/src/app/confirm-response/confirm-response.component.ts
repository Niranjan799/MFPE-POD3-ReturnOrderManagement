import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-confirm-response',
  templateUrl: './confirm-response.component.html',
  styleUrls: ['./confirm-response.component.css']
})
export class ConfirmResponseComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
